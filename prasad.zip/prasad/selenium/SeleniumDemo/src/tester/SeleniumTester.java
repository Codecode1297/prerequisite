package tester;

import org.openqa.selenium.By.ByClassName;
import org.openqa.selenium.By.ByName;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SeleniumTester {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "E:\\B4Testing\\chromedriver.exe");

		WebDriver driver = new ChromeDriver();


		driver.get("www.google.com");
//
//		driver.findElement(ByName.name("q")).sendKeys("gmail");
//		driver.findElement(ByName.name("btnK")).submit();

	}

}
