package tester;

import org.openqa.selenium.By;
import org.openqa.selenium.By.ByClassName;
import org.openqa.selenium.By.ById;
import org.openqa.selenium.By.ByName;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SeleniumTester {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\dac\\Desktop\\chromedriver.exe");

		WebDriver driver = new ChromeDriver();

		
//			driver.get("http://www.facebook.com");

//			driver.findElement(ByName.name("firstname")).sendKeys("Prasad");
//
//			driver.findElement(ByName.name("lastname")).sendKeys("Deshkar");
//
//			driver.findElement(ByName.name("reg_email__")).sendKeys("prasaddeshkar7@gmail.com");
//
//			driver.findElement(ByName.name("reg_email_confirmation__")).sendKeys("prasaddeshkar7@gmail.com");
//
//			driver.findElement(ByName.name("reg_passwd__")).sendKeys("prasad_123");
//
//			driver.findElement(ByName.name("birthday_day")).sendKeys("0");
//
//			driver.findElement(ByName.name("birthday_day")).sendKeys("1");
//			
//			driver.findElement(ByName.name("birthday_month")).sendKeys("JANUARY");
//
//			driver.findElement(ByName.name("birthday_year")).sendKeys("2001");
//
//			driver.findElement(ById.id("u_0_a")).click();
//
//			driver.findElement(ByName.name("websubmit")).click();
		
		
		driver.get("http://www.google.com");
		
		
		driver.findElement(ByName.name("q")).sendKeys("CDAC");
		//btnK	
		
		driver.findElement(ByName.name("btnK")).submi;
		
		
		
		
		
		
		
	}

}
